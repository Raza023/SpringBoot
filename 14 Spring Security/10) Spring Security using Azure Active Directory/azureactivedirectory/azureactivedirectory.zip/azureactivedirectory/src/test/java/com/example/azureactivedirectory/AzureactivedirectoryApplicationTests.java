package com.example.azureactivedirectory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AzureactivedirectoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
