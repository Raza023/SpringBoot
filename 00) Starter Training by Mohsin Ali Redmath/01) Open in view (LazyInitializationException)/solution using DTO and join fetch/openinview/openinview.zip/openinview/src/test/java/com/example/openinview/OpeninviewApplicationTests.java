package com.example.openinview;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OpeninviewApplicationTests {

	@Test
	void contextLoads() {
	}

}
