package com.example.openinview;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OpeninviewApplication {

	public static void main(String[] args) {
		SpringApplication.run(OpeninviewApplication.class, args);
	}

}
