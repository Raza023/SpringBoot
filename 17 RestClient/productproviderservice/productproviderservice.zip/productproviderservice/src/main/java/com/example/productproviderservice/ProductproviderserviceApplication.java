package com.example.productproviderservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductproviderserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductproviderserviceApplication.class, args);
	}

}
