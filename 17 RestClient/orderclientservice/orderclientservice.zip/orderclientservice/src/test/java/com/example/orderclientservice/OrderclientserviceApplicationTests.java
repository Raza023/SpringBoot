package com.example.orderclientservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderclientserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
